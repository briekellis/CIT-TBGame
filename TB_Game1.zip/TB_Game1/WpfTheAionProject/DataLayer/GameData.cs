﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfTheAionProject.Models;

namespace WpfTheAionProject.DataLayer
{
    /// <summary>
    /// static class to store the game data set
    /// </summary>
    public static class GameData
    {
        public static Player PlayerData()
        {
            return new Player()
            {
                Id = 1,
                Name = "Erin",
                Age = 23,
                JobTitle = Player.JobTitleName.Detective,
                Race = Character.RaceType.Human,
                Health = 100,
                ExperiencePoints = 10,
                LocationId = 0
            };
        }

        public static List<string> InitialMessages()
        {
            return new List<string>()
            {
                "\tYou have been contacted by the Salem Police Department to help in solving the murder of a local townsperson. Your mission is to deduce which od the subjects commited the act and report back to the chief of police",
                "\tYou can begin by choosing a new location and traveling to that point in the town.\n\tThere will be items to interact with in some of the locations. Use these to help solve the case."
            };
        }

        public static GameMapCoordinates InitialGameMapLocation()
        {
            return new GameMapCoordinates() { Row = 0, Column = 0 };
        }

        public static Map GameMap()
        {
            int rows = 3;
            int columns = 4;

            Map gameMap = new Map(rows, columns);

            //
            // row 1
            //
            gameMap.MapLocations[0, 0] = new Location()
            {
                Id = 4,
                Name = "Salem Police Department",
                Description = "The Salem Police Department is located at the heart of Salem " +
                "Massachusetts. There is the sound of coffee pots brewing, printers spitting out case files " +
                "and people discussing recent crimes that have taken place throughout the town.",
                Accessible = true,
                ModifiyExperiencePoints = 10
            };
            gameMap.MapLocations[0, 1] = new Location()
            {
                Id = 1,
                Name = "Salem Town Park - The Crime Scene",
                Description = "A few hours ago, in the Salem Town Park, " +
                "a murder took place. The 23 year old Rebecca Southerlands was found dead a few feet from her own front door " +"" +
                "few clues were available upon initial inspection. It's up to you to find more and determine which suspect is responsible.",
                Accessible = true,
                ModifiyExperiencePoints = 10
            };

            //
            // row 2
            //
            gameMap.MapLocations[1, 1] = new Location()
            {
                Id = 2,
                Name = "86'd",
                Description = "86'd is a popular club on the outskirts of town, " +
                "many of the suspects in this case spend their time here, along with the other bored Salem residents.",
                Accessible = true,
                ModifiyExperiencePoints = 10
            };
            gameMap.MapLocations[1, 2] = new Location()
            {
                Id = 2,
                Name = "Victor Hugo's House (Suspect #1)",
                Description = "Victor resides in his small town home " +
                "The yellow paint coating the exterior has begun to chip away, revealing a dark grey coat of old paint. " +
                "The garage door stood agape, revealing many old rusted tools and an old Ford Pinto - the engine missing from under it's hood. " +
                "the doorbell was disconnected. Looks like knocking is the only option.",
                Accessible = false,
                ModifiyExperiencePoints = 50,
                RequiredExperiencePoints = 40                
            };

            //
            // row 3
            //
            gameMap.MapLocations[2, 0] = new Location()
            {
                Id = 3,
                Name = "Mark Hankle's House (Suspect #2)",
                Description = "Mark lives in a nice tudor style house. " +
                "The outside of it is a glaring white, blinding in the direct sunlight." +
                "The screen door offers little privacy for the residents inside, but you knock anyways (out of courtesy).",
                Accessible = false,
                ModifiyExperiencePoints = 20,
                Message = "A note on the front door reads - please leave packages by side door."
            };
            gameMap.MapLocations[2, 1] = new Location()
            {
                Id = 4,
                Name = "Luigi Pancia's House (Suspect #3)",
                Description = "Luigi lives in a small home. Nothing fancy or out of the ordinary " +
                "A squat fence surrounds his yard, now overgrown with the seasonal weeds and foliage " +
                "ringing the doorbel seems like the best idea on this one.",
                Accessible = true,
                ModifiyExperiencePoints = 10
            };

            return gameMap;
        }
    }
}
