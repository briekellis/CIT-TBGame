﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfTheAionProject.PresentationLayer
{
    /// <summary>
    /// Interaction logic for SuspectGuess.xaml
    /// </summary>
    public partial class SuspectGuess : Window
    {
        public SuspectGuess()
        {
            InitializeComponent();
        }

        private void ExitBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void GuessMark_Click(object sender, RoutedEventArgs e)
        {
            SuspectMessage.Text = MarkMsg;
        }

        private void GuessVictor_Click(object sender, RoutedEventArgs e)
        {
            SuspectMessage.Text = VictorMsg;

        }

        private void GuessLuigi_Click(object sender, RoutedEventArgs e)
        {
            SuspectMessage.Text = LuigiMsg;
        }

        private string LuigiMsg = "I don't know... we should take a look at the evidence and notes again...";
        private string VictorMsg = "You have guessed correctly. We found the brass hammer, the main murder weapon, on his property and the gloves show hos DNA. The broken glass found near the hammer is a result of his rage";
        private string MarkMsg = "I think maybe we should review the evidence... locations and whatnot...";
    }
}
