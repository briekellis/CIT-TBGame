﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfTheAionProject.Models
{
    class Guess
    {
        private string guessMsg;

        public string GuessMsg
        {
            get { return guessMsg; }
            set { guessMsg = value; }
        }

    }
}
