﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfTheAionProject.Models;

namespace WpfTheAionProject.DataLayer
{
    /// <summary>
    /// static class to store the game data set
    /// </summary>
    public static class GameData
    {
        public static Player PlayerData()
        {
            //instantiate player data
            return new Player()
            {
                Id = 1,
                Name = "Erin",
                Age = 23,
                JobTitle = Player.JobTitleName.Detective,
                Race = Character.RaceType.Human,
                Health = 100,
                ExperiencePoints = 10,
                LocationId = 0
            };
        }

        //instantiate game items into the data
        private static GameItem GameItemById(int id)
        {
            return StandardGameItems().FirstOrDefault(i => i.Id == id);
        }

        //initial startup message
        public static List<string> InitialMessages()
        {
            return new List<string>()
            {
                "\tYou have been contacted by the Salem Police Department to help in solving the murder of a local townsperson. Your mission is to deduce which od the subjects commited the act and report back to the chief of police",
                "\tYou can begin by choosing a new location and traveling to that point in the town.\n\tThere will be items to interact with in some of the locations. Use these to help solve the case."
            };
        }

        //initial game start point
        public static GameMapCoordinates InitialGameMapLocation()
        {
            return new GameMapCoordinates() { Row = 0, Column = 0 };
        }

        //sets location data and instantiates it, sets game item locations
        public static Map GameMap()
        {
            int rows = 3;
            int columns = 4;

            Map gameMap = new Map(rows, columns);
            gameMap.StandardGameItems = StandardGameItems();

            //
            // row 1
            //
            gameMap.MapLocations[0, 0] = new Location()
            {
                Id = 4,
                Name = "Salem Police Department",
                Description = "The Salem Police Department is located at the heart of Salem " +
                "Massachusetts. There is the sound of coffee pots brewing, printers spitting out case files " +
                "and people discussing recent crimes that have taken place throughout the town.",
                Accessible = true,
                ModifiyExperiencePoints = 10,
                GameItems = new ObservableCollection<GameItem>
                {
                    GameItemById(0)
                }
            };
            gameMap.MapLocations[0, 1] = new Location()
            {
                Id = 1,
                Name = "Salem Town Park - The Crime Scene",
                Description = "A few hours ago, in the Salem Town Park, " +
                "a murder took place. The 23 year old Rebecca Southerlands was found dead a few feet from her own front door " + "" +
                "few clues were available upon initial inspection. It's up to you to find more and determine which suspect is responsible.",
                Accessible = true,
                ModifiyExperiencePoints = 10,
                GameItems = new ObservableCollection<GameItem>
                {
                    GameItemById(1)
                }
            };

            //
            // row 2
            //
            gameMap.MapLocations[1, 1] = new Location()
            {
                Id = 2,
                Name = "86'd",
                Description = "86'd is a popular club on the outskirts of town, " +
                "many of the suspects in this case spend their time here, along with the other bored Salem residents.",
                Accessible = true,
                ModifiyExperiencePoints = 10,
                GameItems = new ObservableCollection<GameItem>
                {
                    GameItemById(4)
                }
            };
            gameMap.MapLocations[1, 2] = new Location()
            {
                Id = 2,
                Name = "Victor Hugo's House (Suspect #1)",
                Description = "Victor resides in his small town home " +
                "The yellow paint coating the exterior has begun to chip away, revealing a dark grey coat of old paint. " +
                "The garage door stood agape, revealing many old rusted tools and an old Ford Pinto - the engine missing from under it's hood. " +
                "the doorbell was disconnected. Looks like knocking is the only option.",
                Accessible = true,
                ModifiyExperiencePoints = 10,
                GameItems = new ObservableCollection<GameItem>
                {
                    GameItemById(2),
                    GameItemById(3)
                }
            };

            //
            // row 3
            //
            gameMap.MapLocations[2, 0] = new Location()
            {
                Id = 3,
                Name = "Mark Hankle's House (Suspect #2)",
                Description = "Mark lives in a nice tudor style house. " +
                "The outside of it is a glaring white, blinding in the direct sunlight." +
                "The screen door offers little privacy for the residents inside, but you knock anyways (out of courtesy).",
                Accessible = false,
                ModifiyExperiencePoints = 20,
                Message = "A note on the front door reads - please leave packages by side door."
            };
            gameMap.MapLocations[2, 1] = new Location()
            {
                Id = 4,
                Name = "Luigi Pancia's House (Suspect #3)",
                Description = "Luigi lives in a small home. Nothing fancy or out of the ordinary " +
                "A squat fence surrounds his yard, now overgrown with the seasonal weeds and foliage " +
                "ringing the doorbel seems like the best idea on this one.",
                Accessible = true,
                ModifiyExperiencePoints = 10
            };

            return gameMap;
        }

        //sets standard game items in data
        public static List<GameItem> StandardGameItems()
        {
            return new List<GameItem>()
            {
                new GameItem(0, "Hand Gun", 100, "A Glock .380 with a full clip of 9mm bullets... hope I don't have to use it...", 20, "This could prove to be useful... hopefully it doesn't..."),
                new GameItem(1, "Rubber Gloves", 10, "A plain black rubber glove, some of the fingertips are split and the palm looks slick with blood... better get this over to evidence for testing...", 15, "This could be a huge break in the case."),
                new GameItem(2, "Brass Hammer", 15, "A brass hammer with a considerably heavy head. Its handle is stained a dark hue, possibly from oil... or something more sinister...", 15, "It feels very heavy in my hand"),
                new GameItem(3, "Broken Glass", 0, "A shard of broken glass, one side is curved and spider-webbed; like it was hit with a round object...", 15, "I wonder what hit this..."),
                new GameItem(4, "Root Beer", 20, "A cold can of root beer, taken from a hastily abandoned table at 86'd.", 15, "Those guys sure left fast when I walked in... Did I know them?")
            };
        }
    }
}

